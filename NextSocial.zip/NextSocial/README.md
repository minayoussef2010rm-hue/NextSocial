# NextSocial - خطوات التشغيل
1. افتح Firebase Console وأنشئ مشروع، وأضف تطبيق أندرويد باسم الحزمة: com.nextsocial.app
2. نزّل google-services.json وحطه في مجلد app/
3. فعّل Authentication (Email/Password) وأنشئ Firestore Database
4. الصق محتوى firestore.rules في Firestore > Rules
5. افتح المشروع في Android Studio واضغط Run
6. للنشر: Build > Generate Signed App Bundle (.aab)
