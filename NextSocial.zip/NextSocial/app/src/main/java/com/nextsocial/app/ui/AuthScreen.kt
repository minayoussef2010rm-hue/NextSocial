package com.nextsocial.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nextsocial.app.data.Repo

@Composable
fun AuthScreen() {
    var isLogin by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("NextSocial", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text("Share · Connect · Belong", color = MaterialTheme.colorScheme.onBackground.copy(alpha = .7f))
        Spacer(Modifier.height(32.dp))
        if (!isLogin) {
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                loading = true; error = null
                val cb: (String?) -> Unit = { e -> loading = false; error = e }
                if (isLogin) Repo.signIn(email.trim(), pass, cb) else Repo.signUp(name.trim(), email.trim(), pass, cb)
            },
            enabled = !loading && email.isNotBlank() && pass.length >= 6 && (isLogin || name.isNotBlank()),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (isLogin) "Log In" else "Get Started") }
        TextButton(onClick = { isLogin = !isLogin; error = null }) {
            Text(if (isLogin) "Create new account" else "I already have an account")
        }
    }
}
