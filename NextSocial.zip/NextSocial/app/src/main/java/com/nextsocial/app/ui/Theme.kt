package com.nextsocial.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// غيّر اللون الأساسي هنا لو عايز هوية مختلفة
val Primary = Color(0xFF2F7BFF)
val Bg = Color(0xFF0B1220)
val Card = Color(0xFF141C2E)

@Composable
fun NextTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Primary, background = Bg, surface = Card, onPrimary = Color.White),
        content = content
    )
}
