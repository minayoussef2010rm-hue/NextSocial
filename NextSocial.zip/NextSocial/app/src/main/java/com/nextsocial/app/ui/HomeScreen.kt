package com.nextsocial.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nextsocial.app.data.Post
import com.nextsocial.app.data.Repo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val posts by remember { Repo.posts() }.collectAsState(initial = emptyList())
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val uid = Repo.auth.currentUser?.uid

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NextSocial", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
                actions = {
                    Box {
                        TextButton(onClick = { menu = true }) { Text("More") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text("Log out") }, onClick = { menu = false; Repo.signOut() })
                            DropdownMenuItem(text = { Text("Delete account") }, onClick = { menu = false; confirmDelete = true })
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(text, { text = it }, placeholder = { Text("What's on your mind?") }, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { Repo.createPost(text.trim()); text = "" }, enabled = text.isNotBlank()) { Text("Post") }
                }
            }
            items(posts, key = { it.id }) { p -> PostCard(p, uid) }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete account?") },
        text = { Text("This permanently deletes your account.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; Repo.deleteAccount { } }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}

@Composable
fun PostCard(p: Post, uid: String?) {
    var reported by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Text(p.authorName, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(p.text)
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { Repo.toggleLike(p) }) {
                    Text((if (uid in p.likes) "♥ " else "♡ ") + p.likes.size)
                }
                Spacer(Modifier.weight(1f))
                if (uid == p.authorId) TextButton(onClick = { Repo.deletePost(p) }) { Text("Delete") }
                else TextButton(onClick = { Repo.report(p); reported = true }, enabled = !reported) {
                    Text(if (reported) "Reported" else "Report")
                }
            }
        }
    }
}
