package com.nextsocial.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.userProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    fun signIn(email: String, pass: String, onDone: (String?) -> Unit) {
        auth.signInWithEmailAndPassword(email, pass)
            .addOnCompleteListener { onDone(it.exception?.localizedMessage) }
    }

    fun signUp(name: String, email: String, pass: String, onDone: (String?) -> Unit) {
        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener { t ->
            val user = t.result?.user
            if (t.isSuccessful && user != null) {
                user.updateProfile(userProfileChangeRequest { displayName = name })
                db.collection("users").document(user.uid).set(mapOf("name" to name, "email" to email))
                onDone(null)
            } else onDone(t.exception?.localizedMessage)
        }
    }

    fun signOut() = auth.signOut()

    fun posts(): Flow<List<Post>> = callbackFlow {
        val reg = db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { snap, _ ->
                trySend(snap?.documents?.mapNotNull { d -> d.toObject(Post::class.java)?.copy(id = d.id) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun createPost(text: String) {
        val u = auth.currentUser ?: return
        db.collection("posts").add(
            mapOf(
                "authorId" to u.uid,
                "authorName" to (u.displayName ?: "User"),
                "text" to text,
                "likes" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp()
            )
        )
    }

    fun toggleLike(p: Post) {
        val uid = auth.currentUser?.uid ?: return
        val op = if (uid in p.likes) FieldValue.arrayRemove(uid) else FieldValue.arrayUnion(uid)
        db.collection("posts").document(p.id).update("likes", op)
    }

    fun report(p: Post) {
        val uid = auth.currentUser?.uid ?: return
        db.collection("reports").add(mapOf("postId" to p.id, "by" to uid, "at" to FieldValue.serverTimestamp()))
    }

    fun deletePost(p: Post) { db.collection("posts").document(p.id).delete() }

    // حذف الحساب (مطلوب من جوجل بلاي)
    fun deleteAccount(onDone: (String?) -> Unit) {
        val u = auth.currentUser ?: return
        db.collection("users").document(u.uid).delete()
        u.delete().addOnCompleteListener { onDone(it.exception?.localizedMessage) }
    }
}
