package com.nextsocial.app.data

import com.google.firebase.Timestamp

data class Post(
    val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val text: String = "",
    val likes: List<String> = emptyList(),
    val createdAt: Timestamp? = null
)
