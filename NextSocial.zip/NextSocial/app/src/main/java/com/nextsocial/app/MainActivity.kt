package com.nextsocial.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.firebase.auth.FirebaseAuth
import com.nextsocial.app.data.Repo
import com.nextsocial.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NextTheme {
                var loggedIn by remember { mutableStateOf(Repo.auth.currentUser != null) }
                DisposableEffect(Unit) {
                    val l = FirebaseAuth.AuthStateListener { loggedIn = it.currentUser != null }
                    Repo.auth.addAuthStateListener(l)
                    onDispose { Repo.auth.removeAuthStateListener(l) }
                }
                Surface(Modifier.fillMaxSize(), color = androidx.compose.material3.MaterialTheme.colorScheme.background) {
                    if (loggedIn) HomeScreen() else AuthScreen()
                }
            }
        }
    }
}
